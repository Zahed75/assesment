import 'package:assesment/utils/constants/sizes.dart';
import 'package:flutter/material.dart';

class UPadding {
  UPadding._();

  static const EdgeInsetsGeometry screenPadding = EdgeInsets.all(
    USizes.defaultSpace,
  );
}
